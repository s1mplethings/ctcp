Stub OK testkit for cos-user-v2p.
