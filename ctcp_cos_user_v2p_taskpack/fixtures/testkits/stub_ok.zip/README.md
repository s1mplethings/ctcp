Stub OK testkit: run_all.py writes out/scorecard.json, out/eval.json, out/cloud.ply, and optional out/cloud_sem.ply.
