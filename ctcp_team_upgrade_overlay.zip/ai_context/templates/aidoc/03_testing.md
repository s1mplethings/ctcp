# AI Doc — Testing

## How to run
- verify_repo:
- test_all:

## Case design
- one case tests one feature
