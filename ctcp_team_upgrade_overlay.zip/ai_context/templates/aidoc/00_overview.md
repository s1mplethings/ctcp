# AI Doc — Overview

- Goal:
- Repo root:
- Key commands:
- Where the truth lives (contracts/specs):
