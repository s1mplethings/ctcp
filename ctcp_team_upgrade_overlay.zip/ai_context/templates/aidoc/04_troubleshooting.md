# AI Doc — Troubleshooting

- Common verify failures:
- How to fix:
