# AI Doc — Architecture

## Components
- GUI / CLI:
- Data model:
- Graph pipeline:

## Boundaries
- C++:
- Web:
- Scripts:
