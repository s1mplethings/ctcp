# AI Doc — Workflow

## Gates
- workflow_checks:
- contract_checks:
- doc index check:

## Delivery
- patch:
- overlay zip:
