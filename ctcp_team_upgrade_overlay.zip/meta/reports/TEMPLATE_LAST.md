# Demo Report — LAST

## Goal
-

## Readlist
- (list the files you read and the key constraints)

## Plan
- Docs/Spec
- Code (if allowed)
- Verify
- Report

## Timeline / Trace
- Run folder: `meta/runs/<timestamp>/`
- Trace file: `meta/runs/<timestamp>/TRACE.md`

## Changes
- Files changed:
-

## Verify
- Command:
- Output (key lines):
-

## Questions (only if blocking)
- (write to meta/runs/<ts>/QUESTIONS.md too)

## Next steps
-
