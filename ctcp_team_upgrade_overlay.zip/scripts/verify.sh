#!/usr/bin/env bash
set -euo pipefail
# verify.sh is kept as a thin wrapper. The real gate is verify_repo.
bash scripts/verify_repo.sh
