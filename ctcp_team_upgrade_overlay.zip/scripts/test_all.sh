#!/usr/bin/env bash
set -euo pipefail
python3 tests/run_cases.py
