#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${ROOT}/build"

echo "[verify_repo] repo root: ${ROOT}"

# 1) Build (best-effort)
if command -v cmake >/dev/null 2>&1; then
  echo "[verify_repo] cmake configure..."
  cmake -S "${ROOT}" -B "${BUILD_DIR}" -DCMAKE_BUILD_TYPE=Release
  echo "[verify_repo] cmake build..."
  cmake --build "${BUILD_DIR}" --config Release

  if [ -f "${BUILD_DIR}/CTestTestfile.cmake" ] && command -v ctest >/dev/null 2>&1; then
    echo "[verify_repo] ctest..."
    ctest --test-dir "${BUILD_DIR}" --output-on-failure
  else
    echo "[verify_repo] no tests detected (skipping ctest)"
  fi
else
  echo "[verify_repo] cmake not found; skipping C++ build"
fi

# 2) Web build (best-effort)
if [ -f "${ROOT}/web/package.json" ]; then
  echo "[verify_repo] web/package.json detected"
  if command -v npm >/dev/null 2>&1; then
    pushd "${ROOT}/web" >/dev/null
    if [ -f package-lock.json ]; then npm ci; else npm install; fi
    if node -e "const p=require('./package.json'); process.exit(p.scripts && p.scripts.build ? 0 : 1)"; then
      npm run build
    else
      echo "[verify_repo] no npm build script (skipping)"
    fi
    popd >/dev/null
  else
    echo "[verify_repo] npm not found; skipping web build"
  fi
else
  echo "[verify_repo] no web frontend detected (web/package.json missing)"
fi

# 3) Workflow gate (hard)
echo "[verify_repo] workflow gate"
python3 "${ROOT}/scripts/workflow_checks.py"

# 4) Contract checks (hard)
echo "[verify_repo] contract checks"
python3 "${ROOT}/scripts/contract_checks.py"

# 5) Doc index check (hard)
echo "[verify_repo] doc index check"
python3 "${ROOT}/scripts/sync_doc_links.py" --check

# 6) Tests (optional but recommended)
if [ -f "${ROOT}/scripts/test_all.sh" ]; then
  echo "[verify_repo] tests"
  bash "${ROOT}/scripts/test_all.sh"
else
  echo "[verify_repo] tests: scripts/test_all.sh not found (skip)"
fi

echo "[verify_repo] OK"
