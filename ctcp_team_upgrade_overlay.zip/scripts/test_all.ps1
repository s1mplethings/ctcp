$ErrorActionPreference = "Stop"
python tests\run_cases.py
