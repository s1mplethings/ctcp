# 10-assistant-init-externals生成模板

## 功能点
ctcp_assistant init-externals：生成 meta/externals/<date>-*.md

## 操作
1)
2)

## 预期
-

## 证据
- 输出日志：
- 文件/路径：
