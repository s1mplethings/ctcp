# 07-verify_repo为唯一入口

## 功能点
verify_repo：输出必须包含 workflow gate / contract checks / doc index check

## 操作
1)
2)

## 预期
-

## 证据
- 输出日志：
- 文件/路径：
