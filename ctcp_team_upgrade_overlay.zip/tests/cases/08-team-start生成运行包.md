# 08-team-start生成运行包

## 功能点
ctcp_team start：生成 meta/runs/<ts>/PROMPT.md QUESTIONS.md TRACE.md

## 操作
1)
2)

## 预期
-

## 证据
- 输出日志：
- 文件/路径：
