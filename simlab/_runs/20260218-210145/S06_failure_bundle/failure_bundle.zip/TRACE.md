# SimLab Trace — S06_failure_bundle

- Name: failure should produce evidence bundle
- Started: 2026-02-18T21:02:00
- Sandbox: `D:/.c_projects/adc/ctcp/simlab/_runs/20260218-210145/S06_failure_bundle/sandbox`

## Steps

### Step 1 write
- path: `README.md`
- mode: `append`

## Failure
- Reason: bundle_on_nonzero: command exited 1
