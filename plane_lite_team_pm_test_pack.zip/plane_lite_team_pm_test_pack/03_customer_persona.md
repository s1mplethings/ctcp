# Customer Persona

## Persona ID
`small_indie_game_team_owner`

## Background
The customer leads a 6-person indie game team:
- 1 planner
- 2 programmers
- 1 artist
- 1 tester
- 1 operations person

## Preferences
- wants something simpler than Jira
- wants something more structured than Trello-style loose boards
- wants local deployment
- prefers Chinese-first UI if practical
- cares about visible progress during the run
- expects a final package, not only code fragments

## Behavior style
- starts with a broad goal
- adds constraints after the first reply
- asks for mid-run evidence
- adds one extra feature during the run
- checks final delivery materials carefully

## What this persona values
- clarity
- visible progress
- practical usability
- final completeness

## What causes dissatisfaction
- generic planning talk with no artifacts
- hidden progress
- fake completion
- missing screenshots
- missing README
- missing startup steps
- no packaged delivery
