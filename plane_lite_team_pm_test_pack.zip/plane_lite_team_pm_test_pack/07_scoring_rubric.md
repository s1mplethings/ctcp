# Scoring Rubric

## Hard gates

If any of the following fail, the benchmark should be judged as a hard failure:

1. no runnable result
2. no verification evidence
3. no README or startup steps
4. no final screenshot
5. no packaged deliverable
6. no customer transcript
7. no step acceptance evidence

## Soft scoring (100 total)

- goal understanding: 20
- scope control: 15
- mid-run evidence quality: 15
- implementation completeness: 20
- verification quality: 10
- delivery completeness: 10
- customer-facing clarity: 10

## Final verdict labels

- `pass` — hard gates pass and overall result is strong
- `borderline` — hard gates mostly pass but quality gaps are meaningful
- `fail` — hard gates fail or delivery is materially incomplete
