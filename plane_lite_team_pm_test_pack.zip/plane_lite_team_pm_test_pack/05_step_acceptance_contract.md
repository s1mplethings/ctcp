# Step Acceptance Contract

This benchmark expects step-level acceptance, not only final acceptance.

## Required concept

For each critical step, the system should be able to show or produce evidence for:
- request
- result
- acceptance

## Minimum critical steps to inspect

1. goal freeze
2. scope shaping
3. context collection
4. plan sign-off
5. implementation handoff
6. verification
7. delivery packaging

## Acceptance expectations

### For each critical step
The tester should look for:
- what was requested,
- what was produced,
- whether some reviewer or gate accepted it.

### Minimum acceptance rules
- a producer should not self-approve their own step,
- missing acceptance should block downstream use,
- blocked steps should produce a visible reason,
- final reporting should show where the first failure occurred.

## Evidence preference

Prefer concrete artifacts over claims:
- json files
- markdown summaries
- logs
- bundle contents
- verify outputs
- screenshots
