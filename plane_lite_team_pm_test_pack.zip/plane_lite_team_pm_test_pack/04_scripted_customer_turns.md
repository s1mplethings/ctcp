# Scripted Customer Turns

The testing agent should use these turns in order unless the system under test makes a turn impossible.

## Turn 1
给我们做一个轻量任务协作平台，能管版本任务、bug 和素材协作，别太复杂，但也别只是待办清单。

## Turn 2
要本地部署，最好中文优先，小团队能直接上手。

## Turn 3
不要只说在做了，我要能看到你现在做到哪一步了，有没有截图或 demo。

## Turn 4
我还想要标签筛选和简单活动记录。

## Turn 5
把最终可运行的内容、README、启动方式、演示数据、截图和打包文件都给我。

## Turn 6
请你自己总结这次交付哪里做得好，哪里没达标。

## Notes for the testing agent
- Do not improve or rewrite the customer's intent.
- Preserve the sequence.
- Record both the customer turn and the system reply.
- If the system asks clarifying questions, answer minimally and keep the scope aligned to this pack.
