# Success Bundle Spec

The final test should judge whether a reviewable acceptance bundle exists.

## Required final bundle contents

The final review bundle should contain, or clearly point to, the following categories:

### A. Customer simulation
- transcript
- transcript summary
- score or judgement
- failure reasons if any

### B. Step acceptance
- step acceptance records or ledger
- stage summary
- handoff or gate summary

### C. CTCP run evidence
- trace
- events log
- verification evidence

### D. Final delivery
- final screenshot(s)
- project package
- public-facing delivery summary

### E. Project usage
- README
- startup steps
- demo data or demo account information
- runnable entrypoint description

## Bundle judgement rule

A bundle is not considered complete if it only contains internal logs.
It must also support human review of:
- what was requested,
- what was built,
- whether it ran,
- what the user would receive.
