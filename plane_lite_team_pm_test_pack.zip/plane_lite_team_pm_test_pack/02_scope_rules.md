# Scope Rules

## Required in MVP

The benchmark project must include all of the following:

1. Local login or a minimal local auth flow
2. Workspace or project concept
3. Task CRUD
4. Board view
5. List view
6. Task detail panel or page
7. Task fields:
   - title
   - description
   - status
   - priority
   - assignee
   - due date
   - labels
8. Comments or activity log
9. Basic filtering
10. Demo data
11. README
12. Startup instructions
13. Final packaged project artifact
14. At least one strong final screenshot

## Nice to have

These are allowed only if they do not break the MVP schedule:
- dark mode
- simple seed data importer
- compact dashboard summary
- export to JSON

## Explicitly forbidden in phase 1

Do not include these in the benchmark MVP:
- multi-tenant architecture
- realtime collaboration
- websocket features
- complex permissions / RBAC matrix
- notifications center
- gantt chart
- roadmap planner
- sprint burndown
- AI scheduling
- third-party OAuth

## Why these limits exist

The benchmark is for testing:
- scope control,
- planning quality,
- implementation quality,
- verification quality,
- delivery quality.

It is not for measuring how many features the agent can pile on.
