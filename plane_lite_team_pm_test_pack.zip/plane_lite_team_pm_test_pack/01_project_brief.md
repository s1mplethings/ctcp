# Project Brief — plane_lite_team_pm

## One-line goal

Build a lightweight team task management platform in the style of a Plane-lite / Focalboard-lite product for a small team.

## Product positioning

The product should feel like:
- more structured than a simple todo list,
- simpler than Jira,
- usable by a small local team without heavy setup.

## Target users

A 3–10 person team, such as:
- indie game team,
- small software studio,
- internal ops team,
- compact creative production team.

## Core product outcome

The delivered project should let a small team:
- log in locally,
- create a workspace or project,
- create and edit tasks,
- view tasks in board and list layouts,
- inspect task details,
- track priority, status, assignee, due date, labels,
- leave comments or activity notes,
- filter tasks,
- start the project locally with clear instructions.

## Delivery expectation

The final result should not be only code.
It should include:
- a runnable project,
- README and startup steps,
- demo data or demo account instructions,
- at least one strong final screenshot,
- a packaged deliverable,
- a final acceptance bundle for review.
