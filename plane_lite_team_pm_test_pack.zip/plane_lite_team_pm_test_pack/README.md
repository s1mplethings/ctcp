# Plane Lite Team PM Test Pack

This pack defines a single benchmark project and the test protocol an agent should use to validate CTCP against it.

## Purpose

Use this pack when you want an agent to:
1. understand exactly what project should be generated,
2. run a realistic customer-style test against CTCP,
3. check step-level acceptance behavior,
4. judge the final delivery package.

## Benchmark Project

**Benchmark ID:** `plane_lite_team_pm`

A lightweight local-first team task management tool for a 3–10 person team.

## What is inside

- `01_project_brief.md` — product goal and target outcome
- `02_scope_rules.md` — required scope and forbidden scope
- `03_customer_persona.md` — the customer identity and preferences
- `04_scripted_customer_turns.md` — exact customer conversation turns
- `05_step_acceptance_contract.md` — per-step acceptance expectations
- `06_success_bundle_spec.md` — what the final acceptance bundle must contain
- `07_scoring_rubric.md` — hard gates and scoring
- `08_agent_test_instructions.md` — what the testing agent must do
- `benchmark_case.json` — machine-readable version of the benchmark

## Intended use

1. Give this zip to the testing agent.
2. Tell the agent to unpack it and treat it as the source of truth for the benchmark.
3. Tell the agent to run the benchmark against CTCP and produce a factual test report.
