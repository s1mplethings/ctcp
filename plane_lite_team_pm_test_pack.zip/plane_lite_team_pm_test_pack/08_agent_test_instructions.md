# Agent Test Instructions

You are the testing agent.

## Your job

Use this pack as the source of truth for the benchmark project and test protocol.

## What you must do

1. Unpack the test pack.
2. Read all files before running.
3. Treat `benchmark_case.json` plus the markdown files as the benchmark definition.
4. Run a realistic customer-style test against CTCP using the scripted turns.
5. Do not silently change the benchmark scope.
6. Prefer factual execution over speculation.
7. If a part fails, try to identify the first real failure point.

## What you must report

At minimum, report:
- commands executed,
- artifacts produced,
- what passed,
- what failed,
- first failure point,
- whether the final bundle is reviewable,
- whether the produced project matches this benchmark.

## Minimum review questions

- Did the system stay within the benchmark scope?
- Did it show visible progress?
- Did it produce step acceptance evidence?
- Did it produce a runnable project?
- Did it produce a useful final delivery package?
