# API Agent Review

Verdict: BLOCK
Reason: review provider fallback blocked: agent command failed rc=1
Required Fix/Artifacts: check logs/plan_agent.* and logs/patch_agent.*
