from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from bug.app import health_payload
from bug.filters import filter_tasks
from bug.seed import load_demo_workspace
from bug.service import generate_project


class TeamTaskPmTests(unittest.TestCase):
    def test_demo_workspace_has_board_list_detail_filter_activity(self) -> None:
        workspace = load_demo_workspace()
        self.assertGreaterEqual(len(workspace["projects"]), 2)
        self.assertGreaterEqual(len(workspace["tasks"]), 8)
        self.assertTrue(filter_tasks(workspace, status="doing"))
        self.assertEqual(health_payload()["archetype"], "team_task_pm_web")

    def test_generate_project_exports_acceptance_bundle(self) -> None:
        with tempfile.TemporaryDirectory(prefix="team_task_pm_") as td:
            result = generate_project(goal="team task pm smoke", project_name="Plane-lite Team PM", out_dir=Path(td))
            self.assertTrue(Path(result["demo_workspace_json"]).exists())
            self.assertTrue(Path(result["task_board_json"]).exists())
            self.assertTrue(Path(result["task_list_json"]).exists())
            self.assertTrue(Path(result["activity_feed_json"]).exists())
            self.assertTrue(Path(result["preview_html"]).exists())
            self.assertTrue(Path(result["acceptance_bundle_zip"]).exists())
            doc = json.loads(Path(result["acceptance_report_json"]).read_text(encoding="utf-8"))
            self.assertEqual(doc["status"], "pass")
            self.assertIn("task_detail_drawer", doc["checks"])


if __name__ == "__main__":
    unittest.main()
