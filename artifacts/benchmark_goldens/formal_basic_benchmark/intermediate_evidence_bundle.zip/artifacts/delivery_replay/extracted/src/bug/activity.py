from __future__ import annotations


def add_activity(workspace: dict[str, object], *, task_id: str, actor: str, action: str, detail: str) -> dict[str, object]:
    rows = workspace.setdefault("activity", [])
    event = {
        "event_id": f"evt_{len(rows) + 1}",
        "task_id": task_id,
        "actor": actor,
        "action": action,
        "detail": detail,
    }
    rows.append(event)
    return event


def comment_on_task(workspace: dict[str, object], *, task_id: str, author: str, body: str) -> dict[str, object]:
    comments = workspace.setdefault("comments", [])
    comment = {
        "comment_id": f"comment_{len(comments) + 1}",
        "task_id": task_id,
        "author": author,
        "body": body,
    }
    comments.append(comment)
    add_activity(workspace, task_id=task_id, actor=author, action="comment", detail=body)
    return comment


def activity_feed(workspace: dict[str, object]) -> list[dict[str, object]]:
    return [row for row in workspace.get("activity", []) if isinstance(row, dict)]
