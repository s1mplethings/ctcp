from __future__ import annotations


def login_with_demo_user(workspace: dict[str, object], name: str = "Avery PM") -> dict[str, object]:
    users = [row for row in workspace.get("users", []) if isinstance(row, dict)]
    for user in users:
        if str(user.get("name", "")) == name:
            return {"authenticated": True, "user": user}
    return {"authenticated": False, "user": users[0] if users else {}}


def list_projects(workspace: dict[str, object]) -> list[dict[str, object]]:
    return [row for row in workspace.get("projects", []) if isinstance(row, dict)]


def create_project(workspace: dict[str, object], *, name: str, description: str) -> dict[str, object]:
    projects = workspace.setdefault("projects", [])
    project = {
        "project_id": f"proj_{len(projects) + 1}",
        "workspace_id": str(workspace.get("workspace_id", "workspace")),
        "name": name,
        "description": description,
    }
    projects.append(project)
    return project
