from __future__ import annotations


def filter_tasks(
    workspace: dict[str, object],
    *,
    status: str | None = None,
    assignee: str | None = None,
    label: str | None = None,
    priority: str | None = None,
) -> list[dict[str, object]]:
    rows = [row for row in workspace.get("tasks", []) if isinstance(row, dict)]
    if status:
        rows = [row for row in rows if row.get("status") == status]
    if assignee:
        rows = [row for row in rows if row.get("assignee") == assignee]
    if label:
        rows = [row for row in rows if label in list(row.get("labels", []))]
    if priority:
        rows = [row for row in rows if row.get("priority") == priority]
    return rows
