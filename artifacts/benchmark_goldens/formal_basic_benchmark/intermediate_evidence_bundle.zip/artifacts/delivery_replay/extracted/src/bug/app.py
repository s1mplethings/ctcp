from __future__ import annotations

import html

from .activity import activity_feed
from .board import build_kanban_board, build_task_list
from .filters import filter_tasks
from .seed import load_demo_workspace


def health_payload() -> dict[str, object]:
    workspace = load_demo_workspace()
    return {
        "status": "ok",
        "archetype": "team_task_pm_web",
        "project_domain": "team_task_management",
        "tasks": len(workspace.get("tasks", [])),
        "views": ["login", "workspace_project_switcher", "kanban_board", "task_list", "task_detail_drawer"],
    }


def render_preview_html(workspace: dict[str, object]) -> str:
    board = build_kanban_board(workspace)
    tasks = build_task_list(workspace)
    doing = filter_tasks(workspace, status="doing")
    events = activity_feed(workspace)
    columns = []
    for status, rows in board.items():
        cards = "".join(
            f"<article class='task-card'><strong>{html.escape(str(row.get('title', 'Task')))}</strong><span>{html.escape(str(row.get('priority', 'medium')))}</span><small>{html.escape(str(row.get('assignee', 'Unassigned')))}</small></article>"
            for row in rows
        )
        columns.append(f"<section class='kanban-column'><h2>{html.escape(status.title())}</h2>{cards}</section>")
    task_rows = "".join(
        f"<tr><td>{html.escape(str(row.get('title', 'Task')))}</td><td>{html.escape(str(row.get('status', '')))}</td><td>{html.escape(str(row.get('assignee', '')))}</td><td>{html.escape(', '.join(row.get('labels', [])))}</td></tr>"
        for row in tasks
    )
    activity_rows = "".join(
        f"<li><strong>{html.escape(str(row.get('actor', '')))}</strong> {html.escape(str(row.get('action', '')))} - {html.escape(str(row.get('detail', '')))}</li>"
        for row in events
    )
    detail = tasks[0] if tasks else {}
    return f'''<!doctype html>
<html><head><meta charset="utf-8"><title>Plane-lite Team PM</title>
<style>
body{{margin:0;font-family:Arial,sans-serif;background:#f6f8fb;color:#18202f}}
header{{display:flex;justify-content:space-between;align-items:center;padding:18px 24px;background:#ffffff;border-bottom:1px solid #d8dee9}}
main{{display:grid;grid-template-columns:1.2fr .8fr;gap:18px;padding:20px}}
.kanban-board{{display:grid;grid-template-columns:repeat(5,1fr);gap:10px}}
.kanban-column,.panel{{background:#fff;border:1px solid #d8dee9;border-radius:8px;padding:12px}}
.task-card{{display:grid;gap:5px;padding:10px;margin:8px 0;border:1px solid #d8dee9;border-radius:6px;background:#fbfcff}}
table{{width:100%;border-collapse:collapse}}td,th{{border-bottom:1px solid #e5e9f0;padding:8px;text-align:left}}
.filters{{display:flex;gap:8px;flex-wrap:wrap}}.filter-chip{{border:1px solid #a7b1c2;border-radius:16px;padding:5px 9px;background:#fff}}
</style></head>
<body>
<header><h1>Plane-lite Team PM</h1><div class="filters"><span class="filter-chip">workspace</span><span class="filter-chip">project</span><span class="filter-chip">status: doing ({len(doing)})</span><span class="filter-chip">assignee</span></div></header>
<main>
<section><h2>kanban_board</h2><div class="kanban-board">{''.join(columns)}</div></section>
<aside class="panel"><h2>task_detail_drawer</h2><p><strong>{html.escape(str(detail.get('title', 'Task detail')))}</strong></p><p>{html.escape(str(detail.get('description', '')))}</p><p>priority: {html.escape(str(detail.get('priority', '')))}</p><p>due: {html.escape(str(detail.get('due_date', '')))}</p></aside>
<section class="panel"><h2>task_list</h2><table><tbody>{task_rows}</tbody></table></section>
<section class="panel"><h2>activity_feed</h2><ul>{activity_rows}</ul></section>
</main></body></html>'''
