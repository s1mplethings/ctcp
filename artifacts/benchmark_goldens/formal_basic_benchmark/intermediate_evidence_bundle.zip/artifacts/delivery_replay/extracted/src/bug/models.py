from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class User:
    user_id: str
    name: str
    role: str = "member"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Workspace:
    workspace_id: str
    name: str
    user_ids: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Project:
    project_id: str
    workspace_id: str
    name: str
    description: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Task:
    task_id: str
    project_id: str
    title: str
    description: str
    status: str
    priority: str
    assignee: str
    due_date: str
    labels: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Comment:
    comment_id: str
    task_id: str
    author: str
    body: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ActivityEvent:
    event_id: str
    task_id: str
    actor: str
    action: str
    detail: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
