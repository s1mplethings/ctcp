from __future__ import annotations


VALID_STATUSES = ("backlog", "todo", "doing", "review", "done")
VALID_PRIORITIES = ("low", "medium", "high", "urgent")


def create_task(
    workspace: dict[str, object],
    *,
    project_id: str,
    title: str,
    description: str,
    assignee: str,
    priority: str = "medium",
    due_date: str = "",
    labels: list[str] | None = None,
) -> dict[str, object]:
    tasks = workspace.setdefault("tasks", [])
    task = {
        "task_id": f"task_{len(tasks) + 1}",
        "project_id": project_id,
        "title": title,
        "description": description,
        "status": "todo",
        "priority": priority if priority in VALID_PRIORITIES else "medium",
        "assignee": assignee,
        "due_date": due_date,
        "labels": list(labels or []),
    }
    tasks.append(task)
    return task


def edit_task_fields(workspace: dict[str, object], task_id: str, **updates: object) -> dict[str, object]:
    task = get_task(workspace, task_id)
    allowed = {"title", "description", "priority", "assignee", "due_date", "labels"}
    for key, value in updates.items():
        if key in allowed:
            task[key] = value
    return task


def move_task_status(workspace: dict[str, object], task_id: str, status: str) -> dict[str, object]:
    if status not in VALID_STATUSES:
        raise ValueError(f"unsupported task status: {status}")
    task = get_task(workspace, task_id)
    task["status"] = status
    return task


def get_task(workspace: dict[str, object], task_id: str) -> dict[str, object]:
    for task in workspace.get("tasks", []):
        if isinstance(task, dict) and task.get("task_id") == task_id:
            return task
    raise KeyError(task_id)
