from __future__ import annotations

from copy import deepcopy


DEMO_WORKSPACE: dict[str, object] = {
    "workspace_id": "ws_team_ops",
    "name": "Team Ops",
    "users": [
        {"user_id": "u1", "name": "Avery PM", "role": "owner"},
        {"user_id": "u2", "name": "Mina Design", "role": "member"},
        {"user_id": "u3", "name": "Kai Build", "role": "member"},
    ],
    "projects": [
        {"project_id": "proj_launch", "workspace_id": "ws_team_ops", "name": "Launch Board", "description": "MVP launch work"},
        {"project_id": "proj_growth", "workspace_id": "ws_team_ops", "name": "Growth Tasks", "description": "Small-team follow-up work"},
    ],
    "tasks": [
        {"task_id": "t1", "project_id": "proj_launch", "title": "Freeze MVP scope", "description": "Confirm board/list/detail scope", "status": "done", "priority": "high", "assignee": "Avery PM", "due_date": "2026-04-24", "labels": ["scope"]},
        {"task_id": "t2", "project_id": "proj_launch", "title": "Build kanban board", "description": "Render backlog/todo/doing/review/done lanes", "status": "doing", "priority": "high", "assignee": "Kai Build", "due_date": "2026-04-27", "labels": ["board", "frontend"]},
        {"task_id": "t3", "project_id": "proj_launch", "title": "Add task detail drawer", "description": "Show title, description, priority, labels, assignee, comments", "status": "review", "priority": "medium", "assignee": "Mina Design", "due_date": "2026-04-28", "labels": ["detail"]},
        {"task_id": "t4", "project_id": "proj_launch", "title": "Wire filters", "description": "Filter by status, assignee, label, priority", "status": "todo", "priority": "medium", "assignee": "Kai Build", "due_date": "2026-04-29", "labels": ["filter"]},
        {"task_id": "t5", "project_id": "proj_growth", "title": "Activity feed", "description": "Record task movement and comments", "status": "doing", "priority": "medium", "assignee": "Avery PM", "due_date": "2026-04-30", "labels": ["activity"]},
        {"task_id": "t6", "project_id": "proj_growth", "title": "Demo seed data", "description": "Ship useful workspaces/projects/tasks", "status": "done", "priority": "low", "assignee": "Mina Design", "due_date": "2026-04-25", "labels": ["sample"]},
        {"task_id": "t7", "project_id": "proj_growth", "title": "README startup steps", "description": "Document local run and export path", "status": "todo", "priority": "high", "assignee": "Avery PM", "due_date": "2026-05-01", "labels": ["delivery"]},
        {"task_id": "t8", "project_id": "proj_growth", "title": "Final screenshot", "description": "Capture real preview page", "status": "backlog", "priority": "medium", "assignee": "Kai Build", "due_date": "2026-05-02", "labels": ["evidence"]},
    ],
    "comments": [
        {"comment_id": "c1", "task_id": "t2", "author": "Avery PM", "body": "Keep the board dense enough for repeated team use."},
        {"comment_id": "c2", "task_id": "t3", "author": "Mina Design", "body": "Detail drawer should keep task fields visible."},
        {"comment_id": "c3", "task_id": "t5", "author": "Kai Build", "body": "Activity rows are ready for acceptance review."},
    ],
    "activity": [
        {"event_id": "e1", "task_id": "t1", "actor": "Avery PM", "action": "move_task_status", "detail": "done"},
        {"event_id": "e2", "task_id": "t2", "actor": "Kai Build", "action": "move_task_status", "detail": "doing"},
        {"event_id": "e3", "task_id": "t3", "actor": "Mina Design", "action": "comment_on_task", "detail": "detail UX reviewed"},
    ],
}


def load_demo_workspace() -> dict[str, object]:
    return deepcopy(DEMO_WORKSPACE)
