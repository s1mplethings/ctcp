from __future__ import annotations

from pathlib import Path

from .activity import add_activity, comment_on_task
from .exporter import export_workspace
from .filters import filter_tasks
from .seed import load_demo_workspace
from .tasks import create_task, edit_task_fields, move_task_status
from .workspace import create_project, login_with_demo_user


def generate_project(*, goal: str, project_name: str, out_dir: Path) -> dict[str, str]:
    workspace = load_demo_workspace()
    login = login_with_demo_user(workspace)
    actor = str(dict(login.get("user", {})).get("name", "Avery PM"))
    project = create_project(workspace, name=f"{project_name} Follow-up", description=goal[:180])
    task = create_task(
        workspace,
        project_id=str(project["project_id"]),
        title="Validate delivery package",
        description="Confirm README, startup, screenshot, verify report, and final package are present.",
        assignee=actor,
        priority="high",
        due_date="2026-05-01",
        labels=["delivery", "acceptance"],
    )
    edit_task_fields(workspace, str(task["task_id"]), description="Confirm the acceptance bundle is reviewable.")
    move_task_status(workspace, str(task["task_id"]), "doing")
    comment_on_task(workspace, task_id=str(task["task_id"]), author=actor, body="Delivery gate evidence is ready for review.")
    add_activity(workspace, task_id=str(task["task_id"]), actor=actor, action="filter", detail=f"{len(filter_tasks(workspace, status='doing'))} doing tasks visible")
    return export_workspace(workspace, out_dir)
