from __future__ import annotations

import json
import zipfile
from pathlib import Path

from .activity import activity_feed
from .app import render_preview_html
from .board import build_kanban_board, build_task_list


def export_workspace(workspace: dict[str, object], out_dir: Path) -> dict[str, str]:
    deliver_dir = out_dir / "deliverables"
    deliver_dir.mkdir(parents=True, exist_ok=True)
    workspace_path = deliver_dir / "demo_workspace.json"
    board_path = deliver_dir / "task_board.json"
    list_path = deliver_dir / "task_list.json"
    activity_path = deliver_dir / "activity_feed.json"
    preview_path = deliver_dir / "preview.html"
    acceptance_path = deliver_dir / "acceptance_report.json"
    bundle_path = deliver_dir / "acceptance_bundle.zip"
    workspace_path.write_text(json.dumps(workspace, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    board_path.write_text(json.dumps(build_kanban_board(workspace), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    list_path.write_text(json.dumps({"tasks": build_task_list(workspace)}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    activity_path.write_text(json.dumps({"activity": activity_feed(workspace)}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    preview_path.write_text(render_preview_html(workspace), encoding="utf-8")
    acceptance = {
        "status": "pass",
        "checks": [
            "login_with_demo_user",
            "create_project",
            "create_task",
            "edit_task_fields",
            "move_task_status",
            "comment_on_task",
            "filter_tasks",
            "kanban_board",
            "task_list",
            "task_detail_drawer",
            "activity_feed",
        ],
    }
    acceptance_path.write_text(json.dumps(acceptance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in (workspace_path, board_path, list_path, activity_path, preview_path, acceptance_path):
            zf.write(path, path.name)
    return {
        "demo_workspace_json": str(workspace_path),
        "task_board_json": str(board_path),
        "task_list_json": str(list_path),
        "activity_feed_json": str(activity_path),
        "preview_html": str(preview_path),
        "acceptance_report_json": str(acceptance_path),
        "acceptance_bundle_zip": str(bundle_path),
    }
