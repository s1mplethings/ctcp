from __future__ import annotations


BOARD_COLUMNS = ("backlog", "todo", "doing", "review", "done")


def build_kanban_board(workspace: dict[str, object]) -> dict[str, list[dict[str, object]]]:
    board: dict[str, list[dict[str, object]]] = {status: [] for status in BOARD_COLUMNS}
    for task in workspace.get("tasks", []):
        if not isinstance(task, dict):
            continue
        board.setdefault(str(task.get("status", "todo")), []).append(task)
    return board


def build_task_list(workspace: dict[str, object]) -> list[dict[str, object]]:
    return sorted(
        [row for row in workspace.get("tasks", []) if isinstance(row, dict)],
        key=lambda row: (str(row.get("project_id", "")), str(row.get("status", "")), str(row.get("priority", ""))),
    )
