# Core Runtime Notes

- project_domain: team_task_management
- scaffold_family: team_task_pm
- project_archetype: team_task_pm_web
- mainline: demo login -> workspace/project -> board/list/detail -> CRUD/filter/activity -> export/delivery
