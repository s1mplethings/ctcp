# Team Task PM Workflow

1. Resolve Plane-lite/Focalboard-lite task collaboration domain.
2. Freeze workspace, project, task, comment, and activity models.
3. Materialize board, list, detail, CRUD, filter, and activity modules.
4. Run health preview and export demo acceptance bundle.
