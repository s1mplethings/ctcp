# Generated Task Card

- Topic: Plane-lite team task management MVP delivery
- Project Type: team_task_pm
- Project Archetype: team_task_pm_web
