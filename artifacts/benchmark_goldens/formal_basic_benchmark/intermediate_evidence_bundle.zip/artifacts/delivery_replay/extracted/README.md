# Plane-lite Team PM

## What This Project Is

A local-first small-team task collaboration platform inspired by Plane-lite and Focalboard-lite. Scoped goal reference: 给我们做一个轻量任务协作平台，能管版本任务、bug 和素材协作，别太复杂，但也别只是待办清单。

## Implemented

- Demo login, workspace/project switcher, kanban board, task list, task detail drawer, task CRUD, filters, comments, and activity feed.
- Seed workspace with demo users, two projects, eight baseline tasks, comments, and activity events.
- Export path for demo workspace JSON, board JSON, task list JSON, activity feed JSON, preview HTML, acceptance report, and acceptance bundle zip.

## Not Implemented

- Realtime websocket collaboration.
- OAuth, RBAC, notifications, Gantt, or roadmap planning.
- Production database or multi-tenant hosting.

## How To Run

`python scripts/run_project_web.py --serve`

Startup steps:

1. Run the command above from the project root.
2. Use `--serve` for a health preview.
3. Run without `--serve` to export demo deliverables into `generated_output/deliverables/`.

## Sample Data

- Demo users: Avery PM, Mina Design, Kai Build.
- Demo projects: Launch Board and Growth Tasks.
- Demo tasks cover backlog, ready, doing, review, and done statuses.

## Directory Map

- `src/` task collaboration domain logic.
- `tests/` service regression coverage.
- `docs/` generated workflow notes.
- `generated_output/` runtime exports after startup.

## Limitations

- This is an MVP for local review, not a hosted SaaS.
- Data is in-memory seed data for deterministic benchmark replay.
- The UI preview is a static export surface for acceptance evidence.

## Repo Context Consumed

- docs/41_low_capability_project_generation.md
- docs/backend_interface_contract.md
- scripts/project_generation_gate.py
- scripts/project_manifest_bridge.py
- workflow_registry/wf_project_generation_manifest/recipe.yaml
