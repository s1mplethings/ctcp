# Data Model Summary

- Workspace owns users and projects.
- Project owns tasks, backlog/milestone metadata, settings, and import/export scope.
- Task contains title, description, status, priority, assignee, due_date, labels, comments, and activity references.
- ActivityEvent records actor/action/detail for timeline review.
