# Page Map / IA

- dashboard: implemented key screen
- project_list: implemented key screen
- project_overview: implemented key screen
- task_list: implemented key screen
- kanban_board: implemented key screen
- task_detail: implemented key screen
- activity_feed: implemented key screen
- project_settings: implemented key screen
