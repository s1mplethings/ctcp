# Mid-stage Evidence Review

- First runnable build exposes dashboard/project switcher/task board/list/detail/activity surfaces.
- Feature completion adds search/filter/sort, backlog, import/export, and project settings evidence.
