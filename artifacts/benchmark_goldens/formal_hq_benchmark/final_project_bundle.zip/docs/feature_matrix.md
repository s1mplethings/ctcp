# Feature Matrix

| Capability | Status |
|---|---|
| task_crud | implemented |
| board_list_dual_view | implemented |
| assignee_priority_due_date_labels | implemented |
| comments_activity_timeline | implemented |
| search_filter_sort | implemented |
| multi_project_switching | implemented |
| backlog | implemented |
| import_workspace_json | implemented |
| export_workspace_json | implemented |
| dashboard_status_priority_summary | implemented |
