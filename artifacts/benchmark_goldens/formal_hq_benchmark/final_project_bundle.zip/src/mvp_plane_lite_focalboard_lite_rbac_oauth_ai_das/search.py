from __future__ import annotations
def search_tasks(workspace: dict[str, object], query: str) -> list[dict[str, object]]:
    q=str(query or '').lower()
    return [task for task in workspace.get('tasks', []) if isinstance(task, dict) and (q in str(task.get('title','')).lower() or q in str(task.get('description','')).lower() or q in ' '.join(str(x).lower() for x in task.get('labels', [])))]
def sort_tasks(tasks: list[dict[str, object]], key: str='due_date') -> list[dict[str, object]]:
    return sorted(tasks, key=lambda row: str(row.get(key, '')))
