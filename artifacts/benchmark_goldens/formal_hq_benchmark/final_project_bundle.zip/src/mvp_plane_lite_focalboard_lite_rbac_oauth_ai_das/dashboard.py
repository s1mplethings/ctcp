from __future__ import annotations
from collections import Counter
def dashboard_summary(workspace: dict[str, object]) -> dict[str, object]:
    tasks=[row for row in workspace.get('tasks', []) if isinstance(row, dict)]
    return {'task_count': len(tasks), 'status_counts': dict(Counter(str(t.get('status','')) for t in tasks)), 'priority_counts': dict(Counter(str(t.get('priority','')) for t in tasks)), 'project_count': len([p for p in workspace.get('projects', []) if isinstance(p, dict)])}
