from __future__ import annotations
import json
from pathlib import Path
def export_workspace_json(workspace: dict[str, object], path: Path) -> str:
    path.parent.mkdir(parents=True, exist_ok=True); path.write_text(json.dumps(workspace, ensure_ascii=False, indent=2)+'\n', encoding='utf-8'); return str(path)
def import_workspace_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding='utf-8'))
