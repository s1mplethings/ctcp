from __future__ import annotations
def project_settings(project: dict[str, object]) -> dict[str, object]:
    return {'project_id': project.get('project_id',''), 'name': project.get('name',''), 'default_view': 'kanban_board', 'enabled_views': ['dashboard','list','board','activity'], 'import_export_enabled': True}
