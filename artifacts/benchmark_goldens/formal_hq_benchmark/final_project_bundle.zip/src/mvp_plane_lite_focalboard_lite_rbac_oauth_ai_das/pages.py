from __future__ import annotations
PAGES=['dashboard','project_list','project_overview','task_list','kanban_board','task_detail','activity_feed','project_settings']
def page_map() -> list[dict[str, str]]:
    return [{'page_id': page, 'status': 'implemented'} for page in PAGES]
