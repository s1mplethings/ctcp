# Plane-lite Team PM

## What This Project Is

A local-first small-team task collaboration platform inspired by Plane-lite and Focalboard-lite. Scoped goal reference: 我们这次不是要最小 MVP。请按 Plane-lite / Focalboard-lite 风格做一个更厚、更像正式产品的小团队任务协作平台：本地部署、中文优先、不要实时协作/多租户/RBAC/OAuth/AI 排期。必须包含 Dashboard、项目列表、单项目总览、任务列表、看板、任务详情、活动流、设置/项目配置；任务 CRUD、board/list 双视图、assignee/priority/due date/labels、评论或

## Implemented

- Demo login, workspace/project switcher, kanban board, task list, task detail drawer, task CRUD, filters, comments, and activity feed.
- Seed workspace with demo users, two projects, eight baseline tasks, comments, and activity events.
- Export path for demo workspace JSON, board JSON, task list JSON, activity feed JSON, preview HTML, acceptance report, and acceptance bundle zip.

## Not Implemented

- Realtime websocket collaboration.
- OAuth, RBAC, notifications, Gantt, or roadmap planning.
- Production database or multi-tenant hosting.

## How To Run

`python scripts/run_project_web.py --serve`

Startup steps:

1. Run the command above from the project root.
2. Use `--serve` for a health preview.
3. Run without `--serve` to export demo deliverables into `generated_output/deliverables/`.

## Sample Data

- Demo users: Avery PM, Mina Design, Kai Build.
- Demo projects: Launch Board and Growth Tasks.
- Demo tasks cover backlog, ready, doing, review, and done statuses.

## Directory Map

- `src/` task collaboration domain logic.
- `tests/` service regression coverage.
- `docs/` generated workflow notes.
- `generated_output/` runtime exports after startup.

## Limitations

- This is an MVP for local review, not a hosted SaaS.
- Data is in-memory seed data for deterministic benchmark replay.
- The UI preview is a static export surface for acceptance evidence.

## Repo Context Consumed

- docs/41_low_capability_project_generation.md
- docs/backend_interface_contract.md
- scripts/project_generation_gate.py
- scripts/project_manifest_bridge.py
- workflow_registry/wf_project_generation_manifest/recipe.yaml

## Feature Matrix

| Area | Coverage |
|---|---|
| Dashboard summaries | implemented |
| Project list and overview | implemented |
| Task list and kanban board | implemented |
| Task detail, comments, activity | implemented |
| Search/filter/sort | implemented |
| Import/export | implemented |

## Page Map

- Dashboard
- Project list
- Project overview
- Task list
- Kanban board
- Task detail
- Activity feed
- Project settings

## Data Model Summary

- Workspace -> users/projects.
- Project -> tasks/backlog/settings.
- Task -> title/description/status/priority/assignee/due_date/labels/comments/activity.

## Replay Steps

1. Run the startup command.
2. Export demo deliverables.
3. Review `artifacts/screenshots/` for the eight page coverage images.
