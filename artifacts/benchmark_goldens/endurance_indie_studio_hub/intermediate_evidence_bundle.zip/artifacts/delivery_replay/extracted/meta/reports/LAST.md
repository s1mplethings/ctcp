# Generated Report

## Readlist
- indie studio production hub domain contract

## Plan
- materialize dashboard/tasks/assets/bugs/releases/docs and export evidence

## Changes
- generated composite local-first indie studio production hub MVP

## Verify
- health preview and export probes are available

## Questions
- none

## Demo
- preview.html, release_summary.json, docs bundle, and acceptance_bundle.zip exported
