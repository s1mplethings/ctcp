# Core Runtime Notes

- project_domain: indie_studio_production_hub
- scaffold_family: indie_studio_hub
- project_archetype: indie_studio_hub_web
- mainline: dashboard -> project overview -> milestone backlog -> task board/list/detail -> asset library/detail -> bug tracker -> build release center -> docs center -> export bundle
