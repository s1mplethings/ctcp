# Startup Guide

1. Run the launcher.
2. Use --serve for health payload.
3. Run export mode for deliverables.
