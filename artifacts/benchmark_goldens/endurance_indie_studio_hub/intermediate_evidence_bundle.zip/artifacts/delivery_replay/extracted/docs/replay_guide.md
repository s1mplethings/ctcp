# Replay Guide

1. Export deliverables.
2. Review preview and JSON exports.
3. Confirm screenshots and docs bundle.
