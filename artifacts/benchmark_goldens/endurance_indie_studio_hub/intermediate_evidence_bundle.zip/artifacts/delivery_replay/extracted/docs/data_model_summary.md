# Data Model Summary

- Workspace, Project, Milestone, Task, Asset, Bug, BuildRecord, ReleaseSummary, and DocEntry are first-class models.
