# Feature Matrix

- Dashboard
- Project Overview
- Milestone Backlog
- Task Board/List/Detail
- Asset Library/Detail
- Bug Tracker
- Build / Release Center
- Activity Feed
- Docs Center
- Project Settings
