# Milestone Plan

- Pre-production
- Vertical Slice
- Release Candidate
- Final Delivery
