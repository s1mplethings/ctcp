# Indie Studio Production Hub Workflow

1. Freeze project, milestone, task, asset, bug, build, release, and docs-center models.
2. Materialize dashboard, project views, task board/list/detail, asset library/detail, bug tracker, build/release center, activity feed, and docs center.
3. Export release summary, asset library, bug tracker, docs center, and acceptance bundle.
