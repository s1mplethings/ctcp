# Indie Studio Production Hub

## What This Project Is

A local-first production collaboration hub for a 5-20 person indie game or VN team. Scoped goal reference: 我想做一个给独立游戏团队用的本地生产协作平台。 团队大概 5 到 20 人，主要有策划、程序、美术、测试、制作人。 我不想只要普通任务看板，我希望它能把任务、素材、Bug、版本进度、发布准备这些东西放在一起。 不要做成很重的企业系统，但最终要像一个真的可以长期使用的产品。

## Implemented

- Dashboard, project list/overview, milestone backlog, task board/list/detail, activity feed, and project settings.
- Asset library plus asset detail for character art, backgrounds, BGM, SFX, script fragments, and replacement tracking.
- Bug tracker with severity, repro steps, linked version, linked tasks/assets, and QA flow.
- Build / Release center with build records, release summary, current version status, and release checklist.
- Docs Center plus export bundle for feature matrix, page map, data model summary, milestone plan, startup guide, replay guide, and mid-stage review.

## Not Implemented

- Realtime websocket collaboration.
- OAuth, cloud sync, multi-tenant SaaS, complex RBAC, AI scheduling, or payment flows.

## How To Run

`python scripts/run_project_web.py --serve`

Startup steps:

1. Run the command above from the project root.
2. Use `--serve` for the health payload and preview contract.
3. Run without `--serve` to export demo deliverables into `generated_output/deliverables/`.

## Sample Data

- Demo users: producer, design, engineering, art, and QA.
- Demo project: Episode One vertical slice with backlog, assets, bugs, and release checklist.
- Demo assets include character portrait, background, bgm, and script fragment placeholders.
- Demo bugs and builds show version progress across the same local workspace.

## Directory Map

- `src/` domain logic for tasks, assets, bugs, releases, docs, and export.
- `docs/` shipped product-definition and replay docs.
- `tests/` service regression coverage.
- `generated_output/` runtime exports after startup.

## Limitations

- This MVP is local-first and single-workspace.
- Data is deterministic in-memory seed data for repeatable replay.
- The preview is a static export surface, not a live collaborative frontend.

## Repo Context Consumed

- docs/41_low_capability_project_generation.md
- docs/backend_interface_contract.md
- scripts/project_generation_gate.py
- scripts/project_manifest_bridge.py
- workflow_registry/wf_project_generation_manifest/recipe.yaml
