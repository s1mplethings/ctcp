from __future__ import annotations
def project_settings(project: dict[str, object]) -> dict[str, object]:
    return {'project_id': project.get('project_id',''), 'name': project.get('name',''), 'default_view': 'dashboard', 'enabled_views': ['dashboard','board','assets','bugs','release','docs'], 'docs_center_enabled': True, 'export_enabled': True}
