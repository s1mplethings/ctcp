from __future__ import annotations

from pathlib import Path

from .activity import add_activity, comment_on_task
from .assets import create_asset
from .bugs import report_bug, update_bug_status
from .exporter import export_workspace
from .releases import create_build_record
from .seed import load_demo_workspace
from .tasks import create_task, move_task_status
from .workspace import create_project, login_with_demo_user


def generate_project(*, goal: str, project_name: str, out_dir: Path) -> dict[str, str]:
    workspace = load_demo_workspace()
    login = login_with_demo_user(workspace)
    actor = str(dict(login.get("user", {})).get("name", "Rin Producer"))
    project = create_project(workspace, name=project_name, description=goal[:180])
    task = create_task(
        workspace,
        project_id=str(project["project_id"]),
        title="Finalize hub coverage review",
        description="Confirm task, asset, bug, build, docs, and replay evidence.",
        assignee=actor,
        priority="high",
        due_date="2026-05-02",
        labels=["delivery", "hub"],
    )
    asset = create_asset(workspace, project_id=str(project["project_id"]), name="Release Banner", asset_type="marketing_art", owner=actor)
    bug = report_bug(workspace, project_id=str(project["project_id"]), title="Release summary typo", severity="minor", version="0.3.1", owner=actor)
    build = create_build_record(workspace, project_id=str(project["project_id"]), version="0.3.1", branch="release-candidate", owner=actor)
    move_task_status(workspace, str(task["task_id"]), "doing")
    update_bug_status(workspace, str(bug["bug_id"]), "review")
    comment_on_task(workspace, task_id=str(task["task_id"]), author=actor, body=f"Linked {asset['asset_id']} and {build['build_id']} for final review.")
    add_activity(workspace, task_id=str(task["task_id"]), actor=actor, action="release_review", detail="docs_center and release summary verified")
    return export_workspace(workspace, out_dir)
