from __future__ import annotations

import html

from .activity import activity_feed
from .assets import asset_detail, asset_library
from .board import build_kanban_board, build_task_list
from .bugs import bug_tracker
from .dashboard import dashboard_summary
from .docs_center import docs_center_index
from .releases import release_summary
from .seed import load_demo_workspace
from .workspace import milestone_backlog, project_overview


def health_payload() -> dict[str, object]:
    workspace = load_demo_workspace()
    return {
        "status": "ok",
        "archetype": "indie_studio_hub_web",
        "project_domain": "indie_studio_production_hub",
        "tasks": len(workspace.get("tasks", [])),
        "assets": len(workspace.get("assets", [])),
        "bugs": len(workspace.get("bugs", [])),
        "views": [
            "dashboard",
            "project_overview",
            "milestone_backlog",
            "task_board",
            "task_list",
            "task_detail",
            "asset_library",
            "asset_detail",
            "bug_tracker",
            "build_release_center",
            "activity_feed",
            "docs_center",
            "project_settings",
        ],
    }


def render_preview_html(workspace: dict[str, object]) -> str:
    overview = project_overview(workspace, project_id="proj_episode_one")
    board = build_kanban_board(workspace)
    tasks = build_task_list(workspace)
    assets = asset_library(workspace)
    selected_asset = asset_detail(workspace, "asset_portrait_heroine") or (assets[0] if assets else {})
    bugs = bug_tracker(workspace)
    release = release_summary(workspace)
    docs = docs_center_index(workspace)
    milestones = milestone_backlog(workspace)
    events = activity_feed(workspace)
    dashboard = dashboard_summary(workspace)
    columns = []
    for status, rows in board.items():
        cards = "".join(
            f"<article class='task-card'><strong>{html.escape(str(row.get('title', 'Task')))}</strong><span>{html.escape(str(row.get('priority', 'medium')))}</span><small>{html.escape(str(row.get('assignee', 'Unassigned')))}</small></article>"
            for row in rows
        )
        columns.append(f"<section class='kanban-column'><h3>{html.escape(status.title())}</h3>{cards}</section>")
    task_rows = "".join(
        f"<tr><td>{html.escape(str(row.get('title', 'Task')))}</td><td>{html.escape(str(row.get('status', '')))}</td><td>{html.escape(str(row.get('assignee', '')))}</td><td>{html.escape(', '.join(row.get('labels', [])))}</td></tr>"
        for row in tasks
    )
    asset_rows = "".join(
        f"<tr><td>{html.escape(str(row.get('name', '')))}</td><td>{html.escape(str(row.get('asset_type', '')))}</td><td>{html.escape(str(row.get('status', '')))}</td><td>{html.escape(str(row.get('owner', '')))}</td></tr>"
        for row in assets
    )
    bug_rows = "".join(
        f"<tr><td>{html.escape(str(row.get('title', '')))}</td><td>{html.escape(str(row.get('severity', '')))}</td><td>{html.escape(str(row.get('status', '')))}</td><td>{html.escape(str(row.get('version', '')))}</td></tr>"
        for row in bugs
    )
    milestone_rows = "".join(
        f"<li>{html.escape(str(row.get('name', '')))} - {html.escape(str(row.get('status', '')))} - {html.escape(str(row.get('due_date', '')))}</li>"
        for row in milestones
    )
    docs_rows = "".join(
        f"<li>{html.escape(str(row.get('title', '')))} - {html.escape(str(row.get('status', '')))}</li>"
        for row in docs
    )
    activity_rows = "".join(
        f"<li><strong>{html.escape(str(row.get('actor', '')))}</strong> {html.escape(str(row.get('action', '')))} - {html.escape(str(row.get('detail', '')))}</li>"
        for row in events
    )
    return f'''<!doctype html>
<html><head><meta charset="utf-8"><title>Indie Studio Production Hub</title>
<style>
body{{margin:0;font-family:Arial,sans-serif;background:#f4f6fb;color:#18202f}}
header{{display:flex;justify-content:space-between;align-items:center;padding:18px 24px;background:#ffffff;border-bottom:1px solid #d8dee9}}
main{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;padding:18px}}
.panel,.kanban-column{{background:#fff;border:1px solid #d8dee9;border-radius:8px;padding:12px}}
.kanban-board{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}}
.task-card{{display:grid;gap:4px;padding:9px;margin:6px 0;border:1px solid #d8dee9;border-radius:6px;background:#fbfcff}}
table{{width:100%;border-collapse:collapse}}td,th{{border-bottom:1px solid #e5e9f0;padding:8px;text-align:left}}
ul{{margin:0;padding-left:18px}} .stats{{display:flex;gap:12px;flex-wrap:wrap}} .chip{{border:1px solid #a7b1c2;border-radius:16px;padding:4px 10px;background:#fff}}
</style></head>
<body>
<header><h1>Indie Studio Production Hub</h1><div class="stats"><span class="chip">dashboard: {dashboard['task_count']} tasks</span><span class="chip">asset_library: {dashboard['asset_count']}</span><span class="chip">bug_tracker: {dashboard['bug_count']}</span><span class="chip">build_release_center: {dashboard['build_count']}</span></div></header>
<main>
<section class="panel"><h2>dashboard</h2><p>project_overview tasks={overview['task_count']} assets={overview['asset_count']} bugs={overview['bug_count']} builds={overview['build_count']}</p></section>
<section class="panel"><h2>milestone_backlog</h2><ul>{milestone_rows}</ul></section>
<section><h2>task_board</h2><div class="kanban-board">{''.join(columns)}</div></section>
<section class="panel"><h2>task_list</h2><table><tbody>{task_rows}</tbody></table><h3>task_detail</h3><p>{html.escape(str(tasks[0].get('description', '')) if tasks else '')}</p></section>
<section class="panel"><h2>asset_library</h2><table><tbody>{asset_rows}</tbody></table></section>
<section class="panel"><h2>asset_detail</h2><p>{html.escape(str(selected_asset.get('name', '')))}</p><p>{html.escape(str(selected_asset.get('asset_type', '')))}</p><p>{html.escape(str(selected_asset.get('status', '')))}</p></section>
<section class="panel"><h2>bug_tracker</h2><table><tbody>{bug_rows}</tbody></table></section>
<section class="panel"><h2>build_release_center</h2><p>version: {html.escape(str(release.get('version', '')))}</p><p>current_version_status: {html.escape(str(release.get('current_version_status', '')))}</p><p>release_summary: {html.escape(str(release.get('release_summary', '')))}</p></section>
<section class="panel"><h2>activity_feed</h2><ul>{activity_rows}</ul></section>
<section class="panel"><h2>docs_center</h2><ul>{docs_rows}</ul></section>
</main></body></html>'''
