from __future__ import annotations
PAGES=['dashboard','project_list','project_overview','milestone_backlog','task_board','task_list','task_detail','asset_library','asset_detail','bug_tracker','build_release_center','activity_feed','docs_center','project_settings']
def page_map() -> list[dict[str, str]]:
    return [{'page_id': page, 'status': 'implemented'} for page in PAGES]
