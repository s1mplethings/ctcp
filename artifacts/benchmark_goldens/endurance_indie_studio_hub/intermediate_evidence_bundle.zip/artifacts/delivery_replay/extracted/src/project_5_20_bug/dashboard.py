from __future__ import annotations

from .assets import asset_library
from .bugs import bug_tracker
from .releases import build_records


def dashboard_summary(workspace: dict[str, object]) -> dict[str, object]:
    tasks = [row for row in workspace.get("tasks", []) if isinstance(row, dict)]
    return {
        "project_count": len([row for row in workspace.get("projects", []) if isinstance(row, dict)]),
        "task_count": len(tasks),
        "asset_count": len(asset_library(workspace)),
        "bug_count": len(bug_tracker(workspace)),
        "build_count": len(build_records(workspace)),
    }
