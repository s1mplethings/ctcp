from __future__ import annotations


def docs_center_index(workspace: dict[str, object]) -> list[dict[str, object]]:
    return [row for row in workspace.get("docs_center", []) if isinstance(row, dict)]


def export_docs_center(workspace: dict[str, object]) -> dict[str, object]:
    return {
        "docs_center": docs_center_index(workspace),
        "required_docs": [
            "feature_matrix.md",
            "page_map.md",
            "data_model_summary.md",
            "milestone_plan.md",
            "startup_guide.md",
            "replay_guide.md",
            "mid_stage_review.md",
        ],
    }
