from __future__ import annotations


def login_with_demo_user(workspace: dict[str, object], *, role: str = "owner") -> dict[str, object]:
    for user in workspace.get("users", []):
        if isinstance(user, dict) and str(user.get("role", "")).strip() == role:
            return {"status": "ok", "user": user}
    users = [row for row in workspace.get("users", []) if isinstance(row, dict)]
    return {"status": "ok", "user": users[0] if users else {}}


def create_project(workspace: dict[str, object], *, name: str, description: str) -> dict[str, object]:
    projects = workspace.setdefault("projects", [])
    project = {"project_id": f"proj_{len(projects) + 1}", "workspace_id": workspace.get("workspace_id", "workspace"), "name": name, "description": description}
    projects.append(project)
    return project


def milestone_backlog(workspace: dict[str, object]) -> list[dict[str, object]]:
    return [row for row in workspace.get("milestones", []) if isinstance(row, dict)]


def project_overview(workspace: dict[str, object], *, project_id: str) -> dict[str, object]:
    tasks = [row for row in workspace.get("tasks", []) if isinstance(row, dict) and row.get("project_id") == project_id]
    assets = [row for row in workspace.get("assets", []) if isinstance(row, dict) and row.get("project_id") == project_id]
    bugs = [row for row in workspace.get("bugs", []) if isinstance(row, dict) and row.get("project_id") == project_id]
    builds = [row for row in workspace.get("builds", []) if isinstance(row, dict) and row.get("project_id") == project_id]
    return {
        "task_count": len(tasks),
        "asset_count": len(assets),
        "bug_count": len(bugs),
        "build_count": len(builds),
    }
