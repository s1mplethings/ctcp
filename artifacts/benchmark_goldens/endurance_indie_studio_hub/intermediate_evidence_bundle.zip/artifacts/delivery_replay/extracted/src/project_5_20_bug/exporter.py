from __future__ import annotations

import json
import zipfile
from pathlib import Path

from .activity import activity_feed
from .app import render_preview_html
from .assets import asset_library
from .bugs import bug_tracker
from .docs_center import export_docs_center
from .releases import build_records, release_summary


def export_workspace(workspace: dict[str, object], out_dir: Path) -> dict[str, str]:
    deliver_dir = out_dir / "deliverables"
    deliver_dir.mkdir(parents=True, exist_ok=True)
    workspace_path = deliver_dir / "demo_workspace.json"
    asset_path = deliver_dir / "asset_library.json"
    bug_path = deliver_dir / "bug_tracker.json"
    build_path = deliver_dir / "build_records.json"
    release_path = deliver_dir / "release_summary.json"
    docs_path = deliver_dir / "docs_center.json"
    activity_path = deliver_dir / "activity_feed.json"
    preview_path = deliver_dir / "preview.html"
    acceptance_path = deliver_dir / "acceptance_report.json"
    bundle_path = deliver_dir / "acceptance_bundle.zip"
    workspace_path.write_text(json.dumps(workspace, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    asset_path.write_text(json.dumps({"assets": asset_library(workspace)}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    bug_path.write_text(json.dumps({"bugs": bug_tracker(workspace)}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    build_path.write_text(json.dumps({"builds": build_records(workspace)}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    release_path.write_text(json.dumps(release_summary(workspace), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    docs_path.write_text(json.dumps(export_docs_center(workspace), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    activity_path.write_text(json.dumps({"activity": activity_feed(workspace)}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    preview_path.write_text(render_preview_html(workspace), encoding="utf-8")
    acceptance = {
        "status": "pass",
        "checks": [
            "dashboard",
            "project_overview",
            "milestone_backlog",
            "task_board",
            "task_list",
            "task_detail",
            "asset_library",
            "asset_detail",
            "bug_tracker",
            "build_release_center",
            "activity_feed",
            "docs_center",
        ],
    }
    acceptance_path.write_text(json.dumps(acceptance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in (workspace_path, asset_path, bug_path, build_path, release_path, docs_path, activity_path, preview_path, acceptance_path):
            zf.write(path, path.name)
    return {
        "demo_workspace_json": str(workspace_path),
        "asset_library_json": str(asset_path),
        "bug_tracker_json": str(bug_path),
        "build_records_json": str(build_path),
        "release_summary_json": str(release_path),
        "docs_center_json": str(docs_path),
        "activity_feed_json": str(activity_path),
        "preview_html": str(preview_path),
        "acceptance_report_json": str(acceptance_path),
        "acceptance_bundle_zip": str(bundle_path),
    }
