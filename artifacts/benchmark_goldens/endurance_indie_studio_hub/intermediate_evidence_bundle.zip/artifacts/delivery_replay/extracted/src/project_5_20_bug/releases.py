from __future__ import annotations


def build_records(workspace: dict[str, object]) -> list[dict[str, object]]:
    return [row for row in workspace.get("builds", []) if isinstance(row, dict)]


def create_build_record(workspace: dict[str, object], *, project_id: str, version: str, branch: str, owner: str) -> dict[str, object]:
    builds = workspace.setdefault("builds", [])
    build = {
        "build_id": f"build_{len(builds) + 1:03d}",
        "project_id": project_id,
        "version": version,
        "branch": branch,
        "status": "candidate",
        "owner": owner,
        "milestone_id": "",
        "release_summary": "",
        "checklist": ["branch merged", "qa smoke", "docs updated"],
    }
    builds.append(build)
    return build


def release_summary(workspace: dict[str, object]) -> dict[str, object]:
    builds = build_records(workspace)
    latest = builds[-1] if builds else {}
    return {
        "current_version_status": str(latest.get("status", "unknown")),
        "version": str(latest.get("version", "")),
        "release_summary": str(latest.get("release_summary", "")),
        "release_checklist": list(latest.get("checklist", [])) if isinstance(latest.get("checklist", []), list) else [],
    }
