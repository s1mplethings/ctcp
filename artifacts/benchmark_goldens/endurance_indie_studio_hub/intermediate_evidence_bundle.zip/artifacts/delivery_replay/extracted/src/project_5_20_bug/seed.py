from __future__ import annotations

from copy import deepcopy


DEMO_WORKSPACE: dict[str, object] = {
    "workspace_id": "ws_indie_studio",
    "name": "Indie Studio Production Hub",
    "users": [
        {"user_id": "u1", "name": "Rin Producer", "role": "owner"},
        {"user_id": "u2", "name": "Aki Design", "role": "design"},
        {"user_id": "u3", "name": "Moe Engineer", "role": "engineering"},
        {"user_id": "u4", "name": "Sora Artist", "role": "art"},
        {"user_id": "u5", "name": "Tao QA", "role": "qa"},
    ],
    "projects": [
        {"project_id": "proj_episode_one", "workspace_id": "ws_indie_studio", "name": "Episode One", "description": "Vertical slice delivery"},
    ],
    "milestones": [
        {"milestone_id": "m1", "project_id": "proj_episode_one", "name": "Vertical Slice", "status": "doing", "owner": "Rin Producer", "due_date": "2026-05-10"},
        {"milestone_id": "m2", "project_id": "proj_episode_one", "name": "Release Candidate", "status": "todo", "owner": "Moe Engineer", "due_date": "2026-05-24"},
    ],
    "tasks": [
        {"task_id": "t1", "project_id": "proj_episode_one", "title": "Freeze opening scene flow", "description": "Lock script beats and branch handoff.", "status": "done", "priority": "high", "assignee": "Aki Design", "due_date": "2026-04-25", "labels": ["narrative"], "asset_ids": ["asset_script_01"], "bug_ids": []},
        {"task_id": "t2", "project_id": "proj_episode_one", "title": "Implement save-room transition", "description": "Wire scene transition and return path.", "status": "doing", "priority": "high", "assignee": "Moe Engineer", "due_date": "2026-04-29", "labels": ["engineering"], "asset_ids": ["asset_bg_room"], "bug_ids": ["bug_001"]},
        {"task_id": "t3", "project_id": "proj_episode_one", "title": "Replace heroine portrait placeholder", "description": "Swap temporary portrait before QA pass.", "status": "review", "priority": "medium", "assignee": "Sora Artist", "due_date": "2026-04-30", "labels": ["art"], "asset_ids": ["asset_portrait_heroine"], "bug_ids": []},
        {"task_id": "t4", "project_id": "proj_episode_one", "title": "QA smoke for build 0.3.0", "description": "Replay branching and collect regressions.", "status": "todo", "priority": "high", "assignee": "Tao QA", "due_date": "2026-05-01", "labels": ["qa"], "asset_ids": [], "bug_ids": ["bug_002"]},
    ],
    "assets": [
        {"asset_id": "asset_portrait_heroine", "project_id": "proj_episode_one", "name": "Heroine Portrait", "asset_type": "character_portrait", "status": "waiting_replacement", "owner": "Sora Artist", "preview": "portrait-v2.png", "linked_task_ids": ["t3"], "missing": False},
        {"asset_id": "asset_bg_room", "project_id": "proj_episode_one", "name": "Save Room Background", "asset_type": "background", "status": "approved", "owner": "Sora Artist", "preview": "bg-room.png", "linked_task_ids": ["t2"], "missing": False},
        {"asset_id": "asset_bgm_theme", "project_id": "proj_episode_one", "name": "Opening Theme", "asset_type": "bgm", "status": "review", "owner": "Aki Design", "preview": "theme-loop.ogg", "linked_task_ids": [], "missing": False},
        {"asset_id": "asset_script_01", "project_id": "proj_episode_one", "name": "Scene Script Fragment", "asset_type": "script_fragment", "status": "approved", "owner": "Aki Design", "preview": "scene-01.txt", "linked_task_ids": ["t1"], "missing": False},
    ],
    "bugs": [
        {"bug_id": "bug_001", "project_id": "proj_episode_one", "title": "Transition fades too early", "severity": "major", "status": "doing", "version": "0.3.0", "linked_task_ids": ["t2"], "linked_asset_ids": ["asset_bg_room"], "repro_steps": ["load save room", "trigger transition", "observe fade"], "owner": "Moe Engineer"},
        {"bug_id": "bug_002", "project_id": "proj_episode_one", "title": "Textbox overlaps portrait", "severity": "minor", "status": "todo", "version": "0.3.0", "linked_task_ids": ["t4"], "linked_asset_ids": ["asset_portrait_heroine"], "repro_steps": ["open dialogue scene", "advance to line 12"], "owner": "Tao QA"},
    ],
    "builds": [
        {"build_id": "build_030", "project_id": "proj_episode_one", "version": "0.3.0", "branch": "vertical-slice", "status": "candidate", "owner": "Moe Engineer", "milestone_id": "m1", "release_summary": "Vertical slice content-complete candidate", "checklist": ["branch merged", "qa smoke", "docs updated"]},
    ],
    "docs_center": [
        {"doc_id": "doc_feature_matrix", "title": "Feature Matrix", "status": "published"},
        {"doc_id": "doc_page_map", "title": "Page Map", "status": "published"},
        {"doc_id": "doc_milestone_plan", "title": "Milestone Plan", "status": "published"},
    ],
    "comments": [
        {"comment_id": "c1", "task_id": "t2", "author": "Rin Producer", "body": "Keep this in the current milestone."},
        {"comment_id": "c2", "task_id": "t3", "author": "Sora Artist", "body": "Replacement portrait is in final review."},
    ],
    "activity": [
        {"event_id": "e1", "task_id": "t1", "actor": "Aki Design", "action": "move_task_status", "detail": "done"},
        {"event_id": "e2", "task_id": "t2", "actor": "Moe Engineer", "action": "move_task_status", "detail": "doing"},
        {"event_id": "e3", "task_id": "t3", "actor": "Sora Artist", "action": "asset_update", "detail": "portrait replacement queued"},
    ],
}


def load_demo_workspace() -> dict[str, object]:
    return deepcopy(DEMO_WORKSPACE)
