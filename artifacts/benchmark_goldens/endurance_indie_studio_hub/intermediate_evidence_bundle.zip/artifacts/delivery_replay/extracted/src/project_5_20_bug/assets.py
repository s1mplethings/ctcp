from __future__ import annotations


def asset_library(workspace: dict[str, object]) -> list[dict[str, object]]:
    return [row for row in workspace.get("assets", []) if isinstance(row, dict)]


def asset_detail(workspace: dict[str, object], asset_id: str) -> dict[str, object]:
    for asset in workspace.get("assets", []):
        if isinstance(asset, dict) and str(asset.get("asset_id", "")).strip() == asset_id:
            return asset
    return {}


def create_asset(workspace: dict[str, object], *, project_id: str, name: str, asset_type: str, owner: str) -> dict[str, object]:
    assets = workspace.setdefault("assets", [])
    asset = {
        "asset_id": f"asset_{len(assets) + 1}",
        "project_id": project_id,
        "name": name,
        "asset_type": asset_type,
        "status": "todo",
        "owner": owner,
        "preview": "",
        "linked_task_ids": [],
        "missing": False,
    }
    assets.append(asset)
    return asset


def mark_asset_missing(workspace: dict[str, object], asset_id: str, *, missing: bool = True) -> dict[str, object]:
    asset = asset_detail(workspace, asset_id)
    if asset:
        asset["missing"] = missing
        asset["status"] = "needs_replacement" if missing else str(asset.get("status", "todo"))
    return asset
