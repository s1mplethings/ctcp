from __future__ import annotations


def bug_tracker(workspace: dict[str, object]) -> list[dict[str, object]]:
    return [row for row in workspace.get("bugs", []) if isinstance(row, dict)]


def report_bug(workspace: dict[str, object], *, project_id: str, title: str, severity: str, version: str, owner: str) -> dict[str, object]:
    bugs = workspace.setdefault("bugs", [])
    bug = {
        "bug_id": f"bug_{len(bugs) + 1:03d}",
        "project_id": project_id,
        "title": title,
        "severity": severity,
        "status": "todo",
        "version": version,
        "linked_task_ids": [],
        "linked_asset_ids": [],
        "repro_steps": [],
        "owner": owner,
    }
    bugs.append(bug)
    return bug


def update_bug_status(workspace: dict[str, object], bug_id: str, status: str) -> dict[str, object]:
    for bug in workspace.get("bugs", []):
        if isinstance(bug, dict) and str(bug.get("bug_id", "")).strip() == bug_id:
            bug["status"] = status
            return bug
    return {}
