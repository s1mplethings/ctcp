from __future__ import annotations
def search_workspace(workspace: dict[str, object], query: str) -> list[dict[str, object]]:
    q=str(query or '').lower()
    pools=[]
    for key in ('tasks','assets','bugs','docs_center'):
        pools.extend([row for row in workspace.get(key, []) if isinstance(row, dict)])
    return [row for row in pools if q in (' '.join(str(v).lower() for v in row.values()))]
def sort_rows(rows: list[dict[str, object]], key: str='status') -> list[dict[str, object]]:
    return sorted(rows, key=lambda row: str(row.get(key, '')))
