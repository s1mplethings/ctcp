from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from project_5_20_bug.app import health_payload
from project_5_20_bug.assets import asset_library
from project_5_20_bug.bugs import bug_tracker
from project_5_20_bug.docs_center import docs_center_index
from project_5_20_bug.releases import release_summary
from project_5_20_bug.seed import load_demo_workspace
from project_5_20_bug.service import generate_project


class IndieStudioHubTests(unittest.TestCase):
    def test_demo_workspace_has_assets_bugs_release_and_docs(self) -> None:
        workspace = load_demo_workspace()
        self.assertGreaterEqual(len(asset_library(workspace)), 4)
        self.assertGreaterEqual(len(bug_tracker(workspace)), 2)
        self.assertTrue(docs_center_index(workspace))
        self.assertEqual(health_payload()["archetype"], "indie_studio_hub_web")
        self.assertEqual(release_summary(workspace)["version"], "0.3.0")

    def test_generate_project_exports_composite_bundle(self) -> None:
        with tempfile.TemporaryDirectory(prefix="indie_studio_hub_") as td:
            result = generate_project(goal="indie studio hub smoke", project_name="Indie Studio Production Hub", out_dir=Path(td))
            for key in (
                "asset_library_json",
                "bug_tracker_json",
                "build_records_json",
                "release_summary_json",
                "docs_center_json",
                "preview_html",
                "acceptance_bundle_zip",
            ):
                self.assertTrue(Path(result[key]).exists(), key)
            doc = json.loads(Path(result["acceptance_report_json"]).read_text(encoding="utf-8"))
            self.assertEqual(doc["status"], "pass")
            self.assertIn("docs_center", doc["checks"])


if __name__ == "__main__":
    unittest.main()
