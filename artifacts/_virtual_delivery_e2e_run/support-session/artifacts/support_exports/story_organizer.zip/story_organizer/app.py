print('story organizer')
