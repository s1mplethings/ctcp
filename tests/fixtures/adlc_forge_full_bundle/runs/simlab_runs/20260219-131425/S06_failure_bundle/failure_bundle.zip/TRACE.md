# SimLab Trace — S06_failure_bundle

- Name: failure should produce evidence bundle
- Started: 2026-02-19T13:14:51
- Sandbox: `D:/.c_projects/adc/ctcp/tests/fixtures/adlc_forge_full_bundle/runs/simlab_runs/20260219-131425/S06_failure_bundle/sandbox`

## Steps

### Step 1 write
- path: `README.md`
- mode: `append`

## Failure
- Reason: bundle_on_nonzero: command exited 1
