# SimLab Trace — S06_failure_bundle

- Name: failure should produce evidence bundle
- Started: 2026-02-18T21:02:35
- Sandbox: `D:/.c_projects/adc/ctcp/tests/fixtures/adlc_forge_full_bundle/runs/simlab_runs/20260218-210222/S06_failure_bundle/sandbox`

## Steps

### Step 1 write
- path: `README.md`
- mode: `append`

## Failure
- Reason: bundle_on_nonzero: command exited 1
