Contents:
- 0001-add-backend-interface-contract.patch
- APPLY_PROMPT.md

Scope:
- Baseline: s1mplethings/ctcp@81f8f35 (3.3.0)
- Docs-only patch
- Adds backend interface contract for standalone backend testing
- Covers file I/O, image I/O, shared-state snapshots, and decision lifecycle
