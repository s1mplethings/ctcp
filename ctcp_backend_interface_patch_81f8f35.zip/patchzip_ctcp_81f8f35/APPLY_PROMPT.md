先以这个基线为准：
repo = s1mplethings/ctcp
branch = main
baseline commit = 81f8f35
version = 3.3.0

硬性要求：
1. 先确认 commit 81f8f35 存在，并且所有分析、修改、patch、测试都默认基于这个 commit。
2. 如果远端有更新，只能先汇报相对 81f8f35 的差异，不能直接跳到最新。
3. 本次任务只做“文档 patch 落地”，不要顺手修改代码、测试、脚本或其他无关文档。
4. 本次 patch 的目标是：补一份明确的 backend interface contract，供“单独测试后端 + 文件/图片输入输出 + shared-state 快照”使用。
5. patch 如果因为行尾或上下文轻微不一致无法直接 apply，可以按 patch 意图手工落到对应文件，但最终改动范围必须等价。

请处理这个 zip 里的 patch：
- 0001-add-backend-interface-contract.patch

目标文件与预期结果：
1. 新增 `docs/backend_interface_contract.md`
2. 在 `docs/frontend_runtime_boundary.md` 追加一个 “Backend Interface Binding” 小节，说明 frontdesk/support 必须绑定正式 backend interface，而不是靠临时文件猜状态
3. 在 `docs/shared_state_contract.md` 追加一个 “Backend Interface Binding” 小节，说明 shared-state snapshot 之外还需要正式的 backend interfaces

这次文档必须明确写清以下内容：
- 现有兼容接口：
  - create_run
  - get_run_status
  - advance_run
  - list_pending_decisions
  - submit_decision
  - upload_input_artifact
  - get_last_report
  - get_support_context
  - record_support_turn
- 新增建议接口：
  - list_output_artifacts
  - get_output_artifact_meta
  - read_output_artifact
  - get_current_state_snapshot
  - get_render_state_snapshot
- decision lifecycle：
  - pending
  - submitted
  - consumed
  - rejected
  - expired
- 图片输入输出要求：
  - 输入图片走通用 artifact upload
  - 输出图片必须能枚举、读 metadata、正式读取
- 验收标准：
  - run 可创建
  - 文件和图片可上传
  - 状态可读
  - run 可推进
  - decision 可列出/提交
  - report 可读
  - 输出 artifact 和图片可枚举/读取
  - current/render snapshots 可读
  - submitted 不能等于 consumed

执行要求：
1. 先报告基线确认结果。
2. 再说明 patch 是否直接 apply 成功；若失败，说明是如何按意图手工落地的。
3. 输出最终修改的文件清单。
4. 不要扩展任务，不要重写无关章节，不要做大范围格式清洗。
5. 最后给出一个简短结论，说明这份文档现在是否足以指导“单独测试后端接口”。
